<?php
$server = "localhost";
$username = "adit";
$password = "1741160052";
$database = "laundrytest";

$conn = mysqli_connect($server, $username, $password, $database);

//mysqli_select_db($database) or die("Datebase tidak bisa dibuka");
?>
